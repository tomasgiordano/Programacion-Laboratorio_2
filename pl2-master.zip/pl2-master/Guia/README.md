# Ejercicios de la guía
_La mayoría de los ejercicios no tienen validación de entrada y no cumplen con el estilo de programación, además pueden no cumplir con exactitud el enunciado._

## Incompletos/sin hacer
- Ejercicio 04
- Ejercicio 05
- Ejercicio 18
- Ejercicio 20
- Ejercicio 40: Falta formulario