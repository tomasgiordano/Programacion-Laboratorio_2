﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio47
{
    public class EquipoFutbol : Equipo
    {
        public EquipoFutbol(string nombre, DateTime fechaCreacion):base(nombre,fechaCreacion) {}
    }
}
