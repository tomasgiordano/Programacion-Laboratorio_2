﻿# Exámenes

## Primer parcial: pp_SistemaSolar
- **Fecha:** `08/10/2019`
- **Nota:** `7`
- **Devolución del profesor/Corrección a realizar:**
  - [ ] Rompe cuando quiere crear el planeta trata de parsear string a Tipo
  
## Segundo parcial: sp_SistemaSolar
- **Fecha:** `19/11/2019`
- **Nota:** `Aprobado`
- **Devolución del profesor/Corrección a realizar:**
  - [ ] Que soy un vago y le meta onda