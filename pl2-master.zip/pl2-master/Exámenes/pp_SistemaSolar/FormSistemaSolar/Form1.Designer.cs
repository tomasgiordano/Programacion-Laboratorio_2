﻿namespace FormSistemaSolar
{
    partial class FormSS
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNombrePlaneta = new System.Windows.Forms.TextBox();
            this.lblNombrePlaneta = new System.Windows.Forms.Label();
            this.labelPlaneta = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTiempoCompletarOrbita = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombreSatelite = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numCompletarRotacion = new System.Windows.Forms.NumericUpDown();
            this.numCompletarOrbitaSatelite = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numCantidadLunas = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.numCompletarRotacionSatelite = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxTipoPlaneta = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonAgregarPlaneta = new System.Windows.Forms.Button();
            this.buttonAgregarSatelite = new System.Windows.Forms.Button();
            this.buttonMostrarInformacion = new System.Windows.Forms.Button();
            this.buttonMoverAstros = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.comboBoxPlaneta = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarRotacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarOrbitaSatelite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCantidadLunas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarRotacionSatelite)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNombrePlaneta
            // 
            this.txtNombrePlaneta.Location = new System.Drawing.Point(164, 6);
            this.txtNombrePlaneta.Name = "txtNombrePlaneta";
            this.txtNombrePlaneta.Size = new System.Drawing.Size(100, 20);
            this.txtNombrePlaneta.TabIndex = 0;
            // 
            // lblNombrePlaneta
            // 
            this.lblNombrePlaneta.AutoSize = true;
            this.lblNombrePlaneta.Location = new System.Drawing.Point(12, 9);
            this.lblNombrePlaneta.Name = "lblNombrePlaneta";
            this.lblNombrePlaneta.Size = new System.Drawing.Size(82, 13);
            this.lblNombrePlaneta.TabIndex = 1;
            this.lblNombrePlaneta.Text = "Nombre planeta";
            // 
            // labelPlaneta
            // 
            this.labelPlaneta.AutoSize = true;
            this.labelPlaneta.Location = new System.Drawing.Point(313, 12);
            this.labelPlaneta.Name = "labelPlaneta";
            this.labelPlaneta.Size = new System.Drawing.Size(43, 13);
            this.labelPlaneta.TabIndex = 3;
            this.labelPlaneta.Text = "Planeta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tiempo en completar orbita";
            // 
            // txtTiempoCompletarOrbita
            // 
            this.txtTiempoCompletarOrbita.Location = new System.Drawing.Point(164, 46);
            this.txtTiempoCompletarOrbita.Name = "txtTiempoCompletarOrbita";
            this.txtTiempoCompletarOrbita.Size = new System.Drawing.Size(100, 20);
            this.txtTiempoCompletarOrbita.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(313, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nombre del satelite";
            // 
            // txtNombreSatelite
            // 
            this.txtNombreSatelite.Location = new System.Drawing.Point(457, 46);
            this.txtNombreSatelite.Name = "txtNombreSatelite";
            this.txtNombreSatelite.Size = new System.Drawing.Size(100, 20);
            this.txtNombreSatelite.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tiempo en completar rotacion";
            // 
            // numCompletarRotacion
            // 
            this.numCompletarRotacion.Location = new System.Drawing.Point(165, 96);
            this.numCompletarRotacion.Name = "numCompletarRotacion";
            this.numCompletarRotacion.Size = new System.Drawing.Size(120, 20);
            this.numCompletarRotacion.TabIndex = 9;
            // 
            // numCompletarOrbitaSatelite
            // 
            this.numCompletarOrbitaSatelite.Location = new System.Drawing.Point(457, 96);
            this.numCompletarOrbitaSatelite.Name = "numCompletarOrbitaSatelite";
            this.numCompletarOrbitaSatelite.Size = new System.Drawing.Size(120, 20);
            this.numCompletarOrbitaSatelite.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(304, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Tiempo en completar orbita";
            // 
            // numCantidadLunas
            // 
            this.numCantidadLunas.Location = new System.Drawing.Point(165, 143);
            this.numCantidadLunas.Name = "numCantidadLunas";
            this.numCantidadLunas.Size = new System.Drawing.Size(120, 20);
            this.numCantidadLunas.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Cantidad de lunas";
            // 
            // numCompletarRotacionSatelite
            // 
            this.numCompletarRotacionSatelite.Location = new System.Drawing.Point(457, 145);
            this.numCompletarRotacionSatelite.Name = "numCompletarRotacionSatelite";
            this.numCompletarRotacionSatelite.Size = new System.Drawing.Size(120, 20);
            this.numCompletarRotacionSatelite.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Tiempo en completar rotacion";
            // 
            // comboBoxTipoPlaneta
            // 
            this.comboBoxTipoPlaneta.FormattingEnabled = true;
            this.comboBoxTipoPlaneta.Location = new System.Drawing.Point(164, 189);
            this.comboBoxTipoPlaneta.Name = "comboBoxTipoPlaneta";
            this.comboBoxTipoPlaneta.Size = new System.Drawing.Size(121, 21);
            this.comboBoxTipoPlaneta.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Tipo planeta";
            // 
            // buttonAgregarPlaneta
            // 
            this.buttonAgregarPlaneta.Location = new System.Drawing.Point(15, 252);
            this.buttonAgregarPlaneta.Name = "buttonAgregarPlaneta";
            this.buttonAgregarPlaneta.Size = new System.Drawing.Size(270, 23);
            this.buttonAgregarPlaneta.TabIndex = 19;
            this.buttonAgregarPlaneta.Text = "Agregar planeta";
            this.buttonAgregarPlaneta.UseVisualStyleBackColor = true;
            this.buttonAgregarPlaneta.Click += new System.EventHandler(this.buttonAgregarPlaneta_Click);
            // 
            // buttonAgregarSatelite
            // 
            this.buttonAgregarSatelite.Location = new System.Drawing.Point(307, 252);
            this.buttonAgregarSatelite.Name = "buttonAgregarSatelite";
            this.buttonAgregarSatelite.Size = new System.Drawing.Size(270, 23);
            this.buttonAgregarSatelite.TabIndex = 20;
            this.buttonAgregarSatelite.Text = "Agregar Satelite";
            this.buttonAgregarSatelite.UseVisualStyleBackColor = true;
            this.buttonAgregarSatelite.Click += new System.EventHandler(this.buttonAgregarSatelite_Click);
            // 
            // buttonMostrarInformacion
            // 
            this.buttonMostrarInformacion.Location = new System.Drawing.Point(15, 281);
            this.buttonMostrarInformacion.Name = "buttonMostrarInformacion";
            this.buttonMostrarInformacion.Size = new System.Drawing.Size(562, 23);
            this.buttonMostrarInformacion.TabIndex = 21;
            this.buttonMostrarInformacion.Text = "Mostrar informacion";
            this.buttonMostrarInformacion.UseVisualStyleBackColor = true;
            this.buttonMostrarInformacion.Click += new System.EventHandler(this.buttonMostrarInformacion_Click);
            // 
            // buttonMoverAstros
            // 
            this.buttonMoverAstros.Location = new System.Drawing.Point(15, 310);
            this.buttonMoverAstros.Name = "buttonMoverAstros";
            this.buttonMoverAstros.Size = new System.Drawing.Size(562, 23);
            this.buttonMoverAstros.TabIndex = 22;
            this.buttonMoverAstros.Text = "Mover Astros";
            this.buttonMoverAstros.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(607, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(279, 321);
            this.richTextBox1.TabIndex = 23;
            this.richTextBox1.Text = "";
            // 
            // comboBoxPlaneta
            // 
            this.comboBoxPlaneta.FormattingEnabled = true;
            this.comboBoxPlaneta.Location = new System.Drawing.Point(457, 12);
            this.comboBoxPlaneta.Name = "comboBoxPlaneta";
            this.comboBoxPlaneta.Size = new System.Drawing.Size(121, 21);
            this.comboBoxPlaneta.TabIndex = 16;
            // 
            // FormSS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(898, 350);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.buttonMoverAstros);
            this.Controls.Add(this.buttonMostrarInformacion);
            this.Controls.Add(this.buttonAgregarSatelite);
            this.Controls.Add(this.buttonAgregarPlaneta);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxTipoPlaneta);
            this.Controls.Add(this.comboBoxPlaneta);
            this.Controls.Add(this.numCompletarRotacionSatelite);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numCantidadLunas);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.numCompletarOrbitaSatelite);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numCompletarRotacion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNombreSatelite);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTiempoCompletarOrbita);
            this.Controls.Add(this.labelPlaneta);
            this.Controls.Add(this.lblNombrePlaneta);
            this.Controls.Add(this.txtNombrePlaneta);
            this.Name = "FormSS";
            this.Text = "Caballero Streppel Andrés";
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarRotacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarOrbitaSatelite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCantidadLunas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCompletarRotacionSatelite)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNombrePlaneta;
        private System.Windows.Forms.Label lblNombrePlaneta;
        private System.Windows.Forms.Label labelPlaneta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTiempoCompletarOrbita;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombreSatelite;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numCompletarRotacion;
        private System.Windows.Forms.NumericUpDown numCompletarOrbitaSatelite;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numCantidadLunas;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numCompletarRotacionSatelite;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxTipoPlaneta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonAgregarPlaneta;
        private System.Windows.Forms.Button buttonAgregarSatelite;
        private System.Windows.Forms.Button buttonMostrarInformacion;
        private System.Windows.Forms.Button buttonMoverAstros;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.ComboBox comboBoxPlaneta;
    }
}

