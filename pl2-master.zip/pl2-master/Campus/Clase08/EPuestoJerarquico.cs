﻿namespace Clase08
{
    public enum EPuestoJerarquico
    {
        Administración,
        Gerencia,
        Sistemas,
        Accionista
    }
}
