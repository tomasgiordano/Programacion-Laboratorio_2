﻿namespace EntidadesSPyFinal
{
    public delegate void DelegadoTransporte(Transporte t);
}
