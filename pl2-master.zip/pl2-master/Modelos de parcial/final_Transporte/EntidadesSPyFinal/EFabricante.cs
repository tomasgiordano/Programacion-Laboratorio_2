﻿namespace EntidadesSPyFinal
{
    public enum EFabricante
    {
        PatitosTransportados,
        AtadosConAlambreTransportes
    }
}