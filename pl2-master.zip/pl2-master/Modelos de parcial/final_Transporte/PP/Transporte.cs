﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesRPP
{
    // HACER ESTA CLASE ABSTRACTA
    //public class Transporte
    //{
    //    private int velocidad;
    //    private EFabricante fabricante;
    //}
}
