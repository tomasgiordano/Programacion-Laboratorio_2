﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPP
{
    public partial class RPPForm : Form
    {
        public RPPForm()
        {
            InitializeComponent();
        }

        private void BtnViajar_Click(object sender, EventArgs e)
        {

        }

        private void BtnAgregarAvion_Click(object sender, EventArgs e)
        {

        }

        private void BtnAgregarTren_Click(object sender, EventArgs e)
        {

        }
    }
}
