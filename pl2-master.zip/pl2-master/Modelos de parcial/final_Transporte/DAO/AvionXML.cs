﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using EntidadesSPyFinal;

namespace Datos
{
    public class AvionXML 
    {
        private static readonly string rutaArchivo;



    }
}
